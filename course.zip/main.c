/**
 * @mainpage Demonstration of Course and Student Libraries
 * 
 * This demonstration shows how multiple function in the course and student libraries
 * work, including:
 * 
 * - enrolling student in a course
 * - printing a course's information
 * - checking the students in a course that are passing
 * - checking the top student in a course
 * - generating random students
 * 
 * @file main.c
 * @author Armaan Nanji
 * @brief A demonstration of the course and student libraries
 * @date 2022-04-07
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief Creates a course and students, and tests various library methods such as enrolling 
 *        students, printing a course/student's information, checking the students in a course 
 *        that are passing, checking the top student and generating a random student.
 * 
 */
int main()
{
  // seed the random number generator
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // enroll 20 randomly generated students with 8 grades into MATH101
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  // Assign the student with the highest average in MATH101 to student and print their infromation
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;

  /* 
    Store the total number of passing students in MATH101 in total_passing and store and array of
    passing students in passing_students. Print the number of passing students and their information.
  */
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}
