/**
* @file course.c
* @author Armaan Nanji
* @date 2022-04-07
* @brief Course library for functions manging courses, including definitions of Course
*        functions.
*
*/

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Appends a Student to the end of a Course's dynamic students array
 * 
 * @param course a course in which the student is to be enrolled in
 * @param student a student who is to be enrolled in the course
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints the name, course code and number of total students for a course, 
 *        and information for each student enrolled in the course, including name, 
 *        ID, grades and average
 * 
 * @param course a course for which the information outlined in the brief will be printed
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");

  // Iterates through all students in course's student array and prints each one's information
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Returns the student in the class with the highest average, in the case many students 
 *        are tied for the highest mark, the student with the lowest index is returned
 * 
 * @param course the course from which to return the top student
 * @return Student* of the top student in the class
 */
Student* top_student(Course* course)
{
  // If there aren't any students in the class do nothing and return NULL
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  /*
    Iterate through the indicies of the students array, if the student at a given index has an averger higher than
    the previously recorded max_average, update the max_average and corresponding student
  */
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Returns a dynamic Student array of all students in a course that are passing, and edits the value 
 *        stored at an int pointer to denote the number of students in the class that are passing
 * 
 * @param course a Course from which we will generate the dynamic array of passing Students
 * @param total_passing an int* which is to point to the number of passing Students in course
 * @return Student* with students that are passing in course
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  /* 
    iterates through the indicies of course's student array, for every student whose average is at least
    50, count is incremented by 1
  */
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  // allocation of heap memory to store an array of passing students
  passing = calloc(count, sizeof(Student));

  int j = 0;
  
  /* 
    iterates through the indicies of course's student array, for every student whose average is at least
    50, add the student to passing at index j, and increment j by 1
  */
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}
