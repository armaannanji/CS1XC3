/**
 * @file student.h
 * @author Armaan Nanji
 * @date 2022-04-07
 * @brief Student library for manging students, including student type definition
 *        and student functions
 * 
 */

/**
 * @brief Student type stores a student with fields first_name, last_name, id, grades 
 *        and num_grades.
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**< the students's first name */
  char last_name[50]; /**< the students's last name */
  char id[11]; /**< the students's id */
  double *grades; /**< the students's grades, denoted using an array */
  int num_grades; /**< the number of grades the student has */
} Student;

// function headders
void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
